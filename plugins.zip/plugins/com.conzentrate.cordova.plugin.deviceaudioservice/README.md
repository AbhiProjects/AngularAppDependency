cordova-plugin-deviceaudioservice

# DeviceAudioService Plugin #
---------------------------
This is the DeviceAudioService Phonegap/Cordova Plugin for iOS.  

The DeviceAudioService is designed to enable simultaneous playback of multiple Url based audio sources from within PhoneGap applications, via a simple API.

It was developed by Conzentrate ApS

# How to use? #
---------------------------
To install this plugin, follow the [Command-line Interface Guide](http://cordova.apache.org/docs/en/edge/guide_cli_index.md.html#The%20Command-line%20Interface).

It's recommended to use cordova command line tool: 

cordova plugin add https://github.com/conzentrate/DeviceAudioService.git

README.txt in docs and src folders provides further details.
